package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.Ipo;

public interface  IpoRepository extends CrudRepository<Ipo, Long>{

}
