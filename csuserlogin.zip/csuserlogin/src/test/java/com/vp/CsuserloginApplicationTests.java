package com.vp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsuserloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
